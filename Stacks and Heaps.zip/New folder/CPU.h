#pragma once
using namespace std;
#include<iostream>
#include<cstdlib>
#include <vector>
#include <fstream>
#include "Jobs.h"
class CPU {
private:
	int idleTime = 0; //Used to track idle time of current job 
	int runningTime = 0; // used to track processing/runtime of current time
	bool b_processing = false;
	bool finishedProc = true;
	jobs current = { 0, 0, 0, 0, 0 };
	int time = 0;
	int processTime = 0;
	int totalRunTime = 0; // used to track run time for a single cpu
	int totalIdleTime = 0; // used to track idle time for a singe cpu
	int numberProcces = 0;
	bool finish = true;
public:
	CPU();
	bool finished();
	bool isFree();
	void setFinished(bool setFinish);
	void setCurrentJob(jobs temp);
	void UpdateTime();
	void Process_Data();
	int getRunTime();
	int getTotalIdleTime();
	int getTotalRunTime();
	int getNumberProcessed();

};

