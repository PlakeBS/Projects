#pragma once
using namespace std;
//sets up jobs
struct jobs {
	char jobType;
	int m_arrivalTime;
	int m_processingTime;
    int m_jobNumber;
    int m_jobTypeNumber;
};

