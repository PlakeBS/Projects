#include "CPU.h"
CPU::CPU()
{
	
}
bool CPU::finished() // to figure out if we have finished processing a piece of data. Mainly used to increase the total jobs completed counter in main
{
	if (runningTime < processTime) {
		return false;
	}
	else {
		return true;
	}
	
}
void CPU::setCurrentJob(jobs temp)
{
	processTime = temp.m_processingTime;
}
void CPU::UpdateTime()// this will update the time we are idle and the amount of time we run for.
{	
	++time;
	if (b_processing) {
		runningTime++;
		totalRunTime++;
	}
	else {
		totalIdleTime++;
		idleTime++;
	}
}
void CPU::Process_Data()
{
	fstream myFile;
	myFile.open("projectT.txt", ios::app);
	
	if (runningTime < processTime) {
		b_processing = true; // we need to keep processing so we label this as true
		if (myFile.is_open()) {
			myFile << " Run time:" << runningTime + 1 << ";" ;
		}
		finishedProc = false;
		idleTime = 0;
	}
	else if (runningTime == processTime) {
		processTime = -1;
	}
	else {	
		runningTime = 0;
		numberProcces++;
		finishedProc = true;
		b_processing = false; // we don't need to keep processing so we label this as false
		if(myFile.is_open()) {
			myFile << " Idle Time: " << idleTime + 1<<";";
		}
	}
	UpdateTime();// keeping track of time
	myFile.close();
}
int CPU::getRunTime()
{
	return runningTime;
}
int CPU::getTotalIdleTime()
{
	return totalIdleTime;
}
int CPU::getTotalRunTime()
{
	return totalRunTime;
}
int CPU::getNumberProcessed()
{
	return numberProcces;
}
bool CPU::isFree()
{
	return finishedProc;	
}

void CPU::setFinished(bool setFinish)
{
	finishedProc = setFinish;
}


