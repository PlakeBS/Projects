#pragma once
using namespace std;
#include<iostream>
#include<cstdlib>
#include <vector>
#include "Jobs.h"
#include "CPU.h"
#include <iostream>
using namespace std;
struct Node
{
	jobs data;
	Node* next;
};
class Queue
{
private:
	Node* top = nullptr;
	vector<jobs> allJobs;
	int timeInQ;
public:
	Queue()
	{
		Node* top = nullptr;
	}
	~Queue()
	{
		Node* destructor = top;
		while (destructor != nullptr) {
			Node* deleteNext = destructor->next;			
			delete destructor;
			destructor = deleteNext;
		}
	}
	int updateTime()
	{
		timeInQ++;
	}
	int length()
	{
		int length = 0;
		Node* count = top;
		while (count != nullptr) {
			count = count->next;
			length++;
		}
		return length;
	}
	bool isFull()
	{
		Node* temp;
		try
		{
			temp = new Node;
			delete temp;
			return false;
		}
		catch (bad_alloc)
		{
			return true;
		}
	}
	bool isEmpty()
	{
		if (top == nullptr)
			return true;
		else
			return false;
	}
	void push(jobs item)
	{
		if (isFull())
			throw bad_alloc();
		else
		{
			Node* current = new Node;
			current->data = item;
			current->next = top;
			top = current;
		}
	}
	void pop()
	{
		if (isEmpty())
		{
			cout << "Stack is empty, can not remove item from stack!"
				<< endl;
			return;
		}
		else
		{
			Node* temp = top;
			top = top->next;
			delete temp;
		}
	}
	jobs peek()
	{
		jobs item = {0,0,0,0,0};
		if (isEmpty())
		{
			cout << "Stack is empty, could not return item from stack!"
				<< endl;
			return item;
		}
		else
			return top->data;
	}
};

