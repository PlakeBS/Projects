using namespace std;
#include<cstdlib>
#include <vector>
#include <iostream>
#include <fstream>
#include "Queue.h"
#include "Jobs.h"
#include "CPU.h"
//this is our sorting algorithm. It will sort given array of jobs by the jobs' arrivalTime from least from greatest/fastest to slowest
template <class ItemType> class Sorting {
private:
public:
	//will take in a vectors memory address so that we can directly modify it
	void  BubbleSort(vector<jobs> &values, int  numValues)
	{
		int  current = 0;

		while (current < numValues - 1)
		{
			//as we call BubbleUp because the first spot of the array should be the smallest element we no need to call it so we increase the current by one everytime 
			BubbleUp(values, current, numValues - 1);
			current++;
		}
	}
	void BubbleUp(vector<jobs> &values, int  start, int end)
	{	
		for (int index = end; index > start; index--) {
			jobs temp;
			//This function will check to see if the values of index and the value to the left of the index have the same arrivalTime if they do they will then be sorted by there job type with type A having prority.
			// We don't need to check for anything else because no two jobs of the same type will be the same, and we do not care about processing time here
			if (values[index].m_arrivalTime == values[index - 1].m_arrivalTime) {
				if (values[index].jobType < values[index].jobType) {
					swap(values[index], values[index - 1]);
				}
			}
			//The basic bubble sort if the value to the index is greater than the value left of the index we will switch the two around so that the lesser number is closer to the start
			else if (values.at(index).m_arrivalTime < values.at(index - 1).m_arrivalTime) {
				
				temp = values[index-1];
				values[index-1] = values[index];
				values[index] = temp;
			}
		}
	}
};
void main()
{
	fstream myFile; // we are just opening up the file that we will be appending the data into later
	myFile.open("projectT.txt", ios::out);
	if (myFile.is_open()) {
		myFile << "";
	}
	myFile.close();
	//setting up constant ints and vectors with the sizes of said constant ints. 
	int const a_jobTotal = 2500, b_jobTotal = 1200, c_jobTotal = 450, total = a_jobTotal + b_jobTotal + c_jobTotal;
	vector<jobs> totalJobs(total), aJob(a_jobTotal), bJob(b_jobTotal), cJob(c_jobTotal);
	int m_AarrivalTime = 0, m_BarrivalTime = 0, m_CarrivalTime = 0;
	//creates all jobs for job type A and puts them into the vector aJob
	for (int i = 0; i < a_jobTotal; i++) {
		m_AarrivalTime = (4 + rand() % 3) + m_AarrivalTime;
		aJob.push_back(jobs());
		aJob[i].jobType = 'A';
		aJob[i].m_arrivalTime = m_AarrivalTime;
		aJob[i].m_processingTime = (1 + rand() % 5);
		aJob[i].m_jobTypeNumber = i + 1;
	}

	//creates all jobs for job type B and puts them into the vector bJob
	for (int i = 0; i < b_jobTotal; i++) {
		m_BarrivalTime = (9 + rand() % 3) + m_BarrivalTime;
		bJob.push_back(jobs());
		bJob[i].jobType = 'B';
		bJob[i].m_arrivalTime = m_BarrivalTime;
		bJob[i].m_processingTime = (6 + rand() % 5);
		bJob[i].m_jobTypeNumber = i + 1;
	}

	//creates all jobs for job type C and puts them into the vector cJob
	for (int i = 0; i < c_jobTotal; i++) {
		m_CarrivalTime = (24 + rand() % 3) + m_CarrivalTime;
		cJob.push_back(jobs());
		cJob[i].jobType = 'C';
		cJob[i].m_arrivalTime = m_CarrivalTime;
		cJob[i].m_processingTime = (9 + rand() % 5);
		cJob[i].m_jobTypeNumber = i + 1;
	}
	//combines all jobs together into one big vector called totalJobs
	for (int i = 0; i < total; i++) {
		totalJobs.push_back(jobs({ 0,0,0,0,0 }));
		//adds all A jobs first
		if (i < a_jobTotal) { 
			totalJobs[i] = aJob[i];

		}
		//then add all B jobs
		else if ((i < a_jobTotal + b_jobTotal)) {

			totalJobs[i] = bJob[i - a_jobTotal];

		}
		//then adds all C jobs
		else if (total > i) {
			totalJobs[i] = cJob[i - a_jobTotal - b_jobTotal];
		}
	}

	//we call the BubbleSort algorithm to sort the totalJobs array
	Sorting<jobs> sort;
	sort.BubbleSort(totalJobs, total);

	myFile.open("projectT.txt", ios::app);

	//prints out sorted array
	if (myFile.is_open()) {
		for (int i = 0; i < total; i++) {
			totalJobs[i].m_jobNumber = i + 1;
			myFile << totalJobs[i].jobType << " " << totalJobs[i].m_arrivalTime << " " << totalJobs[i].m_processingTime << endl;
		}

	}
	int setNumCPU;
	//Just something to make switching number of CPU's easier
	cin >> setNumCPU;
	vector<CPU> c_CPU(setNumCPU);
	int m_whichProccesor = 0; // this will let us keep track of the processors that we are trying to use. We will also be able to have more than one proccesor going at ones.
	int whatJob = 0;
	int jobCounter = 0;
	int m_jobsFinished = 0;
	Queue queue;
	//int m_whichProccesor = 0; // this will let us keep track of the processors that we are trying to use. We will also be able to have more than one proccesor going at ones.
//int whatJob = 0;
//int jobCounter = 0;
	double avgQSize = 0;
	//these will all be used for printing out and keeping track of metrics
	int maxJobsinQ = 0, totalTimeJobInQ = 0, averageTimeInQ = 0, a_arrivedJobs = 0, b_arrivedJobs = 0, c_arrivedJobs = 0, totalJobsCompleted = 0,
		totalIdle = 0, totalProcess = 0, lengthOfQ = 0, temp = 0, m_currentQsize = 0, numNum = 0;
	jobs* tempr = nullptr;

	//For us to process the data set for 500 time units
	for (int currentTime = 0; currentTime < 500; currentTime++) { // This is where we will go for 500 simulated time units
		myFile << "Time: " << currentTime + 1;
		//Checks first to see if the jobs that we are currently on is equal to the total number of jobs, because you can't add more jobs than you have
		if (whatJob != totalJobs.size()) {
			//This is adding new jobs to the queue
			if (totalJobs[whatJob].m_arrivalTime == currentTime) {
				// this is checking to see if more than one thing arrived at the same time and then pushing the extra into the q
				while (totalJobs[whatJob].m_arrivalTime == currentTime) {
					tempr = &totalJobs[whatJob];
					queue.push(totalJobs[whatJob]);
					myFile << "Time " << currentTime << ":\tArrival: Overall Job:" << queue.peek().m_jobNumber << ", Job " <<
						queue.peek().jobType << ":" << queue.peek().m_jobTypeNumber << ", Processing Time " << queue.peek().m_processingTime << ";" << endl
						<< "Time " << currentTime << ":-Begin Processing Job" << queue.peek().m_jobTypeNumber << ", Job " <<
						queue.peek().jobType << ":" << queue.peek().m_jobTypeNumber << ", in CPU " << m_whichProccesor + 1 << endl;
					whatJob++;
					//This is where we keep track of how many total jobs and how many job of each type have come in
					switch (totalJobs[whatJob].jobType)
					{
					case 'C':
						numNum++;
						c_arrivedJobs++;
						break;
					case 'B':
						numNum++;
						b_arrivedJobs++;
						break;
					default:
						numNum++;
						a_arrivedJobs++;
						break;
					}
				}
			}
		}
		// this loop will go through each of the CPUs we have so we can either have them process a job or give them a job to process
		while (m_whichProccesor < c_CPU.size())
		{ 
			if ((queue.isEmpty())) {
				lengthOfQ = 0;
				myFile << " Queue: Empty ";
			}
			else {
				lengthOfQ++;
				myFile << " Queue: " << queue.length();
			}
			myFile << " CPU: " << m_whichProccesor + 1;

			if (!(queue.isEmpty())) { // checks to see if the mainQueue is empty before assiging a new job to a CPU				
				if (c_CPU[m_whichProccesor].finished()) {
					c_CPU[m_whichProccesor].setCurrentJob(queue.peek());
					if (tempr != nullptr) {
						if ((tempr->jobType == queue.peek().jobType) && (tempr->m_jobTypeNumber == queue.peek().m_jobTypeNumber)) {
							totalJobsCompleted++;
						}
					}
					m_jobsFinished++;
					queue.pop();
				}
			}
			c_CPU[m_whichProccesor].Process_Data();
			m_whichProccesor++;
		}
		//resets the processors back down to zero. This way we can keep cycling through the processors
		if (m_whichProccesor == c_CPU.size()) {
			m_whichProccesor = 0;
		}
		//gets max jobs that were in the Q 
		temp = queue.length();
		if (maxJobsinQ < temp) {
			swap(maxJobsinQ, temp);
		}
		
		//setting up metrics
		avgQSize = avgQSize + queue.length();
		totalTimeJobInQ = queue.length() + totalTimeJobInQ;
		m_currentQsize = queue.length();

		myFile << endl;
	}
	//getting the total idle time and run time for the analysis of 0 to 500 time units
	for (int i = 0; i < c_CPU.size(); i++) {
		totalProcess = totalProcess + c_CPU[i].getTotalRunTime();
		totalIdle = totalIdle + c_CPU[i].getTotalIdleTime();
	}
	averageTimeInQ = totalTimeJobInQ / 500;
	avgQSize = avgQSize / 500;
	myFile << "Number of processor(s) being used: " <<  c_CPU.size() << endl;
	myFile << "current queue size: " << m_currentQsize << endl;
	myFile << "Average queue size: " << avgQSize << endl;
	myFile << "Maximum jobs in queue: " << maxJobsinQ << endl;
	myFile << "Total time jobs in queue: " << totalTimeJobInQ << endl;
	myFile << "Average time in queue: " << averageTimeInQ << endl;
	myFile << "Total number of jobs A arrived: " << a_arrivedJobs << endl;
	myFile << "Total number of jobs B arrived: " << b_arrivedJobs << endl;
	myFile << "Total number of jobs C arrived: " << c_arrivedJobs << endl;
	myFile << "Total number of jobs arrived: " << numNum << endl;
	myFile << "Total time CPU(s) were processing: " << totalProcess << endl;
	myFile << "Total time CPU(s) were idle: " << totalIdle << endl;
	myFile << "Total jobs completed: " << m_jobsFinished << endl;

	for (int i = 0; i < c_CPU.size(); i++) {
		totalProcess = totalProcess + c_CPU[i].getTotalRunTime();
	}
	//For us to process the data set for the next 9500 time units
	for (int currentTime = 500; currentTime < 10000; currentTime++) { // This is where we will go for 500 simulated time units
		myFile << "Time: " << currentTime + 1;
		//Checks first to see if the jobs that we are currently on is equal to the total number of jobs, because you can't add more jobs than you have
		if (whatJob != totalJobs.size()) {
			//This is adding new jobs to the queue
			if (totalJobs[whatJob].m_arrivalTime == currentTime) {
				// this is checking to see if more than one thing arrived at the same time and then pushing the extra into the q
				while (totalJobs[whatJob].m_arrivalTime == currentTime) {
					tempr = &totalJobs[whatJob];
					queue.push(totalJobs[whatJob]);
					myFile << "Time " << currentTime << ":\tArrival: Overall Job:" << queue.peek().m_jobNumber << ", Job " <<
						queue.peek().jobType << ":" << queue.peek().m_jobTypeNumber << ", Processing Time " << queue.peek().m_processingTime << ";" << endl
						<< "Time " << currentTime << ":-Begin Processing Job" << queue.peek().m_jobTypeNumber << ", Job " <<
						queue.peek().jobType << ":" << queue.peek().m_jobTypeNumber << ", in CPU " << m_whichProccesor + 1 << endl;
					whatJob++;
					//This is where we keep track of how many total jobs and how many job of each type have come in
					switch (totalJobs[whatJob].jobType)
					{
					case 'C':
						numNum++;
						c_arrivedJobs++;
						break;
					case 'B':
						numNum++;
						b_arrivedJobs++;
						break;
					default:
						numNum++;
						a_arrivedJobs++;
						break;
					}
				}
			}
		}
		// this loop will go through each of the CPUs we have so we can either have them process a job or give them a job to process
			while (m_whichProccesor < c_CPU.size())
			{ // this loop will go through each of the CPUs we have so we can either have them process a job or give them a job to process
				if ((queue.isEmpty())) {
					lengthOfQ = 0;
					myFile << " Queue: Empty ";
				}
				else {
					lengthOfQ++;
					myFile << " Queue: " << queue.length();
				}
				myFile << " CPU: " << m_whichProccesor + 1;

				if (!(queue.isEmpty())) { // checks to see if the mainQueue is empty before assiging a new job to a CPU				
					if (c_CPU[m_whichProccesor].finished()) {
						c_CPU[m_whichProccesor].setCurrentJob(queue.peek());
						if (tempr != nullptr) {
							if ((tempr->jobType == queue.peek().jobType) && (tempr->m_jobTypeNumber == queue.peek().m_jobTypeNumber)) {
								totalJobsCompleted++;
							}
						}
						m_jobsFinished++;
						queue.pop();
					}
				}
				c_CPU[m_whichProccesor].Process_Data();
				m_whichProccesor++;
			}
			//resets the processors back down to zero. This way we can keep cycling through the processors
			if (m_whichProccesor == c_CPU.size()) {
				m_whichProccesor = 0;
			}
			temp = queue.length();
			if (maxJobsinQ < temp) {
				swap(maxJobsinQ, temp);
			}
			
			avgQSize = avgQSize + queue.length();
			totalTimeJobInQ = queue.length() + totalTimeJobInQ;
			m_currentQsize = queue.length();
		
			myFile << endl;
	}
	//getting the total idle time and run time for the analysis of 500 to 9500 time units
	for (int i = 0; i < c_CPU.size(); i++) {
		totalProcess = totalProcess + c_CPU[i].getTotalRunTime();
		totalIdle = totalIdle + c_CPU[i].getTotalIdleTime();
	}
	averageTimeInQ = totalTimeJobInQ / 9500;
	avgQSize = avgQSize / 9500;
	myFile << "Number of processor(s) being used: " << c_CPU.size() << endl;
	myFile << "current queue size: " << m_currentQsize << endl;
	myFile << "Average queue size: " << avgQSize << endl;
	myFile << "Maximum jobs in queue: " << maxJobsinQ << endl;
	myFile << "Total time jobs in queue: " << totalTimeJobInQ << endl;
	myFile << "Average time in queue: " << averageTimeInQ << endl;
	myFile << "Total number of jobs A arrived: " << a_arrivedJobs << endl;
	myFile << "Total number of jobs B arrived: " << b_arrivedJobs << endl;
	myFile << "Total number of jobs C arrived: " << c_arrivedJobs << endl;
	myFile << "Total number of jobs arrived: " << numNum << endl;
	myFile << "Total time CPU(s) were processing: " << totalProcess << endl;
	myFile << "Total time CPU(s) were idle: " << totalIdle << endl;
	myFile << "Total jobs completed: " << m_jobsFinished << endl;
	/*printMetric(c_CPU.size(), m_currentQsize, avgQSize, maxJobsinQ, totalTimeJobInQ, averageTimeInQ, a_arrivedJobs, b_arrivedJobs, c_arrivedJobs, numNum, totalProcess, totalIdle, idk);*/

	myFile.close();
}
